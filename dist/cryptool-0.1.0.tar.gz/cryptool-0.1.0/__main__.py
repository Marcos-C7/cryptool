#!/usr/bin/env python
# -*- coding: utf8 -*-

from .cryptool import main

res = main()
print(res["status"])